
  # LiveConnect Mobile App Design

  This is a code bundle for LiveConnect Mobile App Design. The original project is available at https://www.figma.com/design/HSPCNsuWMDU14aQXAtXt5c/LiveConnect-Mobile-App-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  